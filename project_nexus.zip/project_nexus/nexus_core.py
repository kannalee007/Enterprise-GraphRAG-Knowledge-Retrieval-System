from langchain_neo4j import Neo4jGraph

def main():
    try:
        graph = Neo4jGraph(
            url="bolt://localhost:7687",
            username="neo4j",
            password="password"
        )
        print("✓ Successfully connected to Neo4j database")
    except Exception as e:
        print(f"✗ Failed to connect: {e}")

if __name__ == "__main__":
    main()
