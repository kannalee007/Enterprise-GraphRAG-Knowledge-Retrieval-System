from fastapi import FastAPI, File, UploadFile, Form, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import HTMLResponse
from langchain_neo4j import Neo4jGraph
from langchain_text_splitters import RecursiveCharacterTextSplitter
import ollama
import numpy as np
import uuid
import os
from typing import List, Optional
from pydantic import BaseModel
from io import BytesIO
from PyPDF2 import PdfReader
from urllib.parse import unquote
import json
import re

app = FastAPI(title="Nexus Knowledge Graph Retrieval")

# CORS for frontend access
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# Neo4j connection
graph = Neo4jGraph(
    url="bolt://localhost:7687",
    username="neo4j",
    password="password"
)

# Ensure schema exists
def init_schema():
    """Initialize Neo4j schema with constraints and indexes."""
    try:
        # Create constraint on Document node IDs
        graph.query("""
            CREATE CONSTRAINT document_id IF NOT EXISTS
            FOR (d:Document) REQUIRE d.id IS UNIQUE
        """)
        # Create constraint on Chunk node IDs  
        graph.query("""
            CREATE CONSTRAINT chunk_id IF NOT EXISTS
            FOR (c:Chunk) REQUIRE c.id IS UNIQUE
        """)
        print("✓ Schema constraints created")
    except Exception as e:
        print(f"Schema init note: {e}")
    
    # Try to create vector index separately
    try:
        # Check if vector index exists and drop if wrong dimension
        try:
            graph.query("""
                DROP INDEX chunk_embeddings IF EXISTS
            """)
        except:
            pass
        
        # Create vector index with correct dimension for nomic-embed-text
        graph.query("""
            CREATE VECTOR INDEX chunk_embeddings
            FOR (c:Chunk) ON (c.embedding)
            OPTIONS {indexConfig: {
                `vector.dimensions`: 768,
                `vector.similarity_function`: 'cosine'
            }}
        """)
        print("✓ Vector index created (768 dims)")
    except Exception as e:
        print(f"Vector index note: {e}")
        print("ℹ Will use fallback text search instead")

init_schema()

# Text splitter for chunking
text_splitter = RecursiveCharacterTextSplitter(
    chunk_size=500,
    chunk_overlap=50,
    separators=["\n\n", "\n", ". ", " ", ""]
)

def get_embedding(text: str) -> List[float]:
    """Get embedding from Ollama using nomic-embed-text model."""
    response = ollama.embeddings(model="nomic-embed-text", prompt=text)
    return response["embedding"]

def generate_cypher_query(natural_language: str, schema_info: str) -> str:
    """Use Ollama LLM to convert natural language to Cypher query."""
    prompt = f"""You are a Cypher query expert for Neo4j. 

Database schema:
- (Document)-[:HAS_CHUNK]->(Chunk)
- (Chunk) has properties: id, text, embedding, source
- (Document) has properties: id, title, source, created_at

Convert this natural language query to a valid Cypher query:
"{natural_language}"

Rules:
1. Only return the Cypher query, no explanation
2. Use proper Cypher syntax
3. Use text similarity or CONTAINS for text matching
4. Return relevant nodes and their relationships
5. Limit results to 10 unless specified otherwise

Cypher query:"""

    response = ollama.generate(
        model="qwen2.5:7b",
        prompt=prompt,
        stream=False
    )
    return response["response"].strip()

# Pydantic models
class QueryRequest(BaseModel):
    query: str
    use_vector_search: bool = True
    top_k: int = 5
    session_id: Optional[str] = None  # For conversation memory

class ChatRequest(BaseModel):
    message: str
    session_id: Optional[str] = None

# In-memory conversation store (use Redis/DB for production)
conversations: dict[str, list] = {}

def get_session_history(session_id: str) -> list:
    """Get conversation history for a session."""
    return conversations.get(session_id, [])

def add_to_history(session_id: str, role: str, content: str):
    """Add message to conversation history."""
    if session_id not in conversations:
        conversations[session_id] = []
    conversations[session_id].append({"role": role, "content": content})
    # Keep only last 10 messages
    conversations[session_id] = conversations[session_id][-10:]

class QueryResult(BaseModel):
    cypher_query: Optional[str]
    results: List[dict]
    source: str  # "vector" or "llm_cypher"

@app.get("/")
async def root():
    return {"message": "Nexus Knowledge Graph API", "status": "running"}

@app.get("/health")
async def health():
    """Health check for all services."""
    status = {"api": "ok", "neo4j": "unknown", "ollama": "unknown"}
    
    # Check Neo4j
    try:
        graph.query("RETURN 1")
        status["neo4j"] = "ok"
    except Exception as e:
        status["neo4j"] = f"error: {str(e)}"
    
    # Check Ollama
    try:
        ollama.list()
        status["ollama"] = "ok"
    except Exception as e:
        status["ollama"] = f"error: {str(e)}"
    
    return status

@app.post("/ingest")
async def ingest_document(
    file: UploadFile = File(...),
    title: Optional[str] = Form(None)
):
    """Upload and ingest a document into the Knowledge Graph."""
    
    if not file.filename.endswith(('.txt', '.md', '.py', '.js', '.json', '.pdf')):
        raise HTTPException(400, "Supported: .txt, .md, .py, .js, .json, .pdf")
    
    # Read content
    content = await file.read()
    
    # Extract text based on file type
    if file.filename.endswith('.pdf'):
        try:
            pdf_reader = PdfReader(BytesIO(content))
            text = ""
            for page in pdf_reader.pages:
                text += page.extract_text() + "\n"
            if not text.strip():
                raise HTTPException(400, "PDF has no extractable text (scanned/image PDF)")
        except Exception as e:
            raise HTTPException(400, f"Failed to extract PDF: {str(e)}")
    else:
        text = content.decode("utf-8")
    
    # Create document node
    doc_id = str(uuid.uuid4())
    doc_title = title or file.filename
    
    graph.query("""
        CREATE (d:Document {
            id: $doc_id,
            title: $title,
            source: $source,
            created_at: datetime()
        })
    """, {"doc_id": doc_id, "title": doc_title, "source": file.filename})
    
    # Chunk the text
    chunks = text_splitter.split_text(text)
    
    # Process each chunk
    chunk_count = 0
    for i, chunk_text in enumerate(chunks):
        if not chunk_text.strip():
            continue
            
        chunk_id = f"{doc_id}_chunk_{i}"
        embedding = get_embedding(chunk_text)
        
        # Create chunk node with embedding
        graph.query("""
            CREATE (c:Chunk {
                id: $chunk_id,
                text: $text,
                embedding: $embedding,
                chunk_index: $index,
                source: $source
            })
            WITH c
            MATCH (d:Document {id: $doc_id})
            CREATE (d)-[:HAS_CHUNK]->(c)
        """, {
            "chunk_id": chunk_id,
            "text": chunk_text,
            "embedding": embedding,
            "index": i,
            "source": file.filename,
            "doc_id": doc_id
        })
        
        # Extract entities only from first chunk for speed
        if i == 0 and len(chunk_text) > 50:
            try:
                extracted = extract_entities(chunk_text[:800])
                if extracted.get("entities"):
                    add_entities_to_graph(chunk_id, extracted["entities"])
            except Exception as e:
                print(f"Entity extraction skipped: {e}")
        
        chunk_count += 1
    
    return {
        "success": True,
        "document_id": doc_id,
        "title": doc_title,
        "chunks_created": chunk_count,
        "total_chars": len(text)
    }

def fallback_text_search(query: str, top_k: int) -> List[dict]:
    """Fallback text-based search using CONTAINS."""
    # Break query into keywords for better matching
    keywords = [k for k in query.lower().split() if len(k) > 2]
    
    if not keywords:
        keywords = [query.lower()]
    
    # Search with ANY keyword match
    text_results = graph.query("""
        MATCH (c:Chunk)
        WITH c, [k IN $keywords WHERE toLower(c.text) CONTAINS k] as matches
        WHERE size(matches) > 0
        RETURN c.id as chunk_id, c.text as text, c.source as source, 
               size(matches) as match_count
        ORDER BY match_count DESC
        LIMIT $limit
    """, {"keywords": keywords, "limit": top_k})
    
    return [
        {
            "chunk_id": r["chunk_id"],
            "text": r["text"][:300] + "..." if len(r["text"]) > 300 else r["text"],
            "source": r["source"],
            "score": r["match_count"]
        }
        for r in text_results
    ]

def extract_entities(text: str) -> dict:
    """Extract entities using LLM - optimized for speed."""
    prompt = f"""Extract key entities from this text. Return JSON:
{{"entities": [{{"name": "...", "type": "Technology|Person|Organization|Concept"}}]}}

Text: {text[:600]}

JSON:"""

    try:
        response = ollama.generate(
            model="qwen2.5:7b",
            prompt=prompt,
            stream=False,
            options={"temperature": 0.1, "num_predict": 200}
        )
        
        json_match = re.search(r'\{.*\}', response["response"], re.DOTALL)
        if json_match:
            data = json.loads(json_match.group())
            return data
    except Exception as e:
        print(f"Entity extraction failed: {e}")
    
    return {"entities": []}

def add_entities_to_graph(chunk_id: str, entities: list):
    """Add extracted entities to Neo4j."""
    for entity in entities:
        try:
            name = entity.get("name", "").strip()
            if not name or len(name) < 2:
                continue
            graph.query("""
                MERGE (e:Entity {name: $name, type: $type})
                WITH e
                MATCH (c:Chunk {id: $chunk_id})
                MERGE (c)-[:MENTIONS]->(e)
            """, {
                "name": name,
                "type": entity.get("type", "Unknown"),
                "chunk_id": chunk_id
            })
        except Exception as e:
            print(f"Failed to add entity: {e}")

def is_raw_cypher(query: str) -> bool:
    """Detect if user entered raw Cypher query."""
    cypher_keywords = ['match', 'return', 'where', 'create', 'merge', 'delete', 'set', 'with']
    query_lower = query.lower().strip()
    return any(keyword in query_lower for keyword in cypher_keywords)

def is_safe_cypher(query: str) -> bool:
    """Block destructive Cypher operations."""
    dangerous = ['delete', 'detach', 'remove', 'drop', 'create', 'merge', 'set']
    query_lower = query.lower()
    return not any(d in query_lower for d in dangerous)

@app.post("/query", response_model=QueryResult)
async def query_knowledge_graph(request: QueryRequest):
    """Query the Knowledge Graph using natural language or raw Cypher."""
    
    results = []
    cypher_query = None
    source = "vector"
    
    if request.use_vector_search:
        try:
            # Vector similarity search
            query_embedding = get_embedding(request.query)
            
            # Use Neo4j vector search
            vector_results = graph.query("""
                CALL db.index.vector.queryNodes('chunk_embeddings', $top_k, $embedding)
                YIELD node, score
                RETURN node.id as chunk_id, node.text as text, 
                       node.source as source, score
                ORDER BY score DESC
            """, {"top_k": request.top_k, "embedding": query_embedding})
            
            results = [
                {
                    "chunk_id": r["chunk_id"],
                    "text": r["text"],
                    "source": r["source"],
                    "score": r["score"]
                }
                for r in vector_results
            ]
        except Exception as e:
            print(f"Vector search failed: {e}")
            # Fallback to text search
            results = fallback_text_search(request.query, request.top_k)
            source = "text_fallback"
    else:
        # Check if user entered raw Cypher
        if is_raw_cypher(request.query):
            # Safety check for destructive queries
            if not is_safe_cypher(request.query):
                results = [{"data": {"error": "Only read-only MATCH queries allowed for safety"}, "score": None}]
                source = "cypher_blocked"
            else:
                # Execute raw Cypher directly
                try:
                    cypher_query = request.query.strip()
                    print(f"Executing raw Cypher: {cypher_query}")
                    
                    cypher_results = graph.query(cypher_query)
                    
                    results = [
                        {
                            "data": dict(r),
                            "score": None
                        }
                        for r in cypher_results[:request.top_k]
                    ]
                    source = "cypher_raw"
                except Exception as e:
                    print(f"Raw Cypher execution failed: {e}")
                    results = [{"data": {"error": str(e)}, "score": None}]
                    source = "cypher_error"
        else:
            # Generate Cypher from natural language using LLM
            try:
                cypher_query = generate_cypher_query(request.query)
                print(f"Generated Cypher: {cypher_query}")
                
                # Execute the generated Cypher
                cypher_results = graph.query(cypher_query, {"top_k": request.top_k})
                
                results = [
                    {
                        "data": dict(r),
                        "score": None
                    }
                    for r in cypher_results[:request.top_k]
                ]
                source = "cypher_llm"
            except Exception as e:
                print(f"Cypher generation/execution failed: {e}")
                # Fallback to text search
                results = fallback_text_search(request.query, request.top_k)
                source = "text_fallback"
                cypher_query = None
    
    return {
        "results": results,
        "cypher_query": cypher_query,
        "source": source
    }

@app.get("/entities")
async def list_entities():
    """List all extracted entities in the knowledge graph."""
    entities = graph.query("""
        MATCH (e:Entity)
        OPTIONAL MATCH (e)<-[:MENTIONS]-(c:Chunk)
        RETURN e.name as name, e.type as type, count(c) as mention_count
        ORDER BY mention_count DESC
        LIMIT 50
    """)
    
    return {
        "entities": [dict(e) for e in entities],
        "entity_count": len(entities),
        "relationship_count": 0
    }

@app.get("/explore/{entity_name}")
async def explore_entity(entity_name: str):
    """Explore an entity and its connected chunks."""
    # Decode URL-encoded entity name
    decoded_name = unquote(entity_name)
    
    chunks = graph.query("""
        MATCH (e:Entity {name: $name})<-[:MENTIONS]-(c:Chunk)<-[:HAS_CHUNK]-(d:Document)
        RETURN c.text as text, c.id as chunk_id, d.title as doc_title, d.source as source
        LIMIT 10
    """, {"name": decoded_name})
    
    return {
        "entity": decoded_name,
        "chunks": [dict(c) for c in chunks],
        "related_entities": []
    }

@app.post("/chat")
async def chat_with_kg(request: ChatRequest):
    """Chat with the knowledge graph using conversation memory."""
    session_id = request.session_id or str(uuid.uuid4())
    
    # Get conversation history
    history = get_session_history(session_id)
    
    # First, search for relevant context
    query_embedding = get_embedding(request.message)
    
    try:
        # Vector search for context
        context_results = graph.query("""
            CALL db.index.vector.queryNodes('chunk_embeddings', 3, $embedding)
            YIELD node, score
            RETURN node.text as text, node.source as source, score
            ORDER BY score DESC
        """, {"embedding": query_embedding})
    except:
        # Fallback
        context_results = []
    
    # Build context from results
    context = "\n\n".join([f"From {r['source']}: {r['text'][:300]}" for r in context_results[:3]])
    
    # Build conversation prompt
    history_text = ""
    for msg in history[-5:]:  # Last 5 messages
        role = "User" if msg["role"] == "user" else "Assistant"
        history_text += f"{role}: {msg['content']}\n"
    
    prompt = f"""You are a helpful assistant that answers questions based on the provided knowledge graph context.

Conversation History:
{history_text}

Relevant Context from Knowledge Graph:
{context}

Current Question: {request.message}

Provide a helpful, accurate answer based on the context. If the context doesn't contain enough information, say so. Be concise but thorough.

Answer:"""

    # Generate response
    response = ollama.generate(
        model="qwen2.5:7b",
        prompt=prompt,
        stream=False,
        options={"temperature": 0.7}
    )
    
    answer = response["response"].strip()
    
    # Store in history
    add_to_history(session_id, "user", request.message)
    add_to_history(session_id, "assistant", answer)
    
    return {
        "response": answer,
        "session_id": session_id,
        "sources": [r["source"] for r in context_results[:3]]
    }

@app.get("/documents")
async def list_documents():
    """List all ingested documents."""
    docs = graph.query("""
        MATCH (d:Document)
        OPTIONAL MATCH (d)-[:HAS_CHUNK]->(c)
        OPTIONAL MATCH (c)-[:MENTIONS]->(e:Entity)
        RETURN d.id as id, d.title as title, d.source as source,
               d.created_at as created_at, count(DISTINCT c) as chunk_count,
               count(DISTINCT e) as entity_count
        ORDER BY d.created_at DESC
    """)
    return {"documents": [dict(d) for d in docs]}

@app.delete("/documents/{doc_id}")
async def delete_document(doc_id: str):
    """Delete a document and its chunks."""
    graph.query("""
        MATCH (d:Document {id: $doc_id})
        OPTIONAL MATCH (d)-[:HAS_CHUNK]->(c)
        DETACH DELETE d, c
    """, {"doc_id": doc_id})
    return {"success": True, "deleted": doc_id}

@app.get("/stats")
async def get_stats():
    """Get Knowledge Graph statistics."""
    stats = graph.query("""
        MATCH (d:Document)
        OPTIONAL MATCH (d)-[:HAS_CHUNK]->(c)
        OPTIONAL MATCH (c)-[:MENTIONS]->(e:Entity)
        RETURN count(DISTINCT d) as document_count, 
               count(DISTINCT c) as chunk_count,
               count(DISTINCT e) as entity_count
    """)[0]
    
    return {
        "documents": stats["document_count"],
        "chunks": stats["chunk_count"],
        "entities": stats["entity_count"]
    }

# Serve static files (frontend)
if os.path.exists("static"):
    app.mount("/static", StaticFiles(directory="static"), name="static")

@app.get("/ui", response_class=HTMLResponse)
async def serve_ui():
    """Serve the enhanced web UI from static file."""
    try:
        with open("static/index.html", "r") as f:
            return f.read()
    except FileNotFoundError:
        return HTMLResponse(content="<h1>UI not found. Please create static/index.html</h1>", status_code=404)

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
